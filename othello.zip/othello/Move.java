

public class Move
{
	boolean legal = false;
	int points = 0;
	int x = -1;
	int y = -1;
}  