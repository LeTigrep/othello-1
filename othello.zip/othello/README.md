
pour compiler : javac *.java

pour executer : java Othello  
