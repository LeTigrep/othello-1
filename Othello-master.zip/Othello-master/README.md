Othello
=======
Run the program as one of the following:<br><br> 
  java Othello          (GUI with a default delay time of 1 second)<br>
  java Othello delay    (GUI with a delay of (delay) milliseconds)<br>
  java Othello 0        (GUI with human (Black) vs. machine (White))<br>
  java Othello -delay   (No GUI - run program (delay) times)<br>
